#include "mainwindow.h"
#include <QVBoxLayout>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QMessageBox>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    initUI();
}

MainWindow::~MainWindow() {
    delete textEdit;
    delete fetchButton;
}

void MainWindow::initUI() {
    setWindowTitle("RIA Data Fetcher");

    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QVBoxLayout *layout = new QVBoxLayout(centralWidget);

    textEdit = new QTextEdit(centralWidget);
    textEdit->setReadOnly(true);
    layout->addWidget(textEdit);

    fetchButton = new QPushButton("Fetch Data", centralWidget);
    connect(fetchButton, &QPushButton::clicked, this, &MainWindow::fetchData);
    layout->addWidget(fetchButton);
}

void MainWindow::fetchData() {
    QTcpSocket *socket = new QTcpSocket(this);

    connect(socket, &QTcpSocket::readyRead, this, [this, socket]() {
        static qint32 messageSize = -1;
        static QByteArray buffer;

        while (socket->bytesAvailable() > 0) {
            if (messageSize == -1) {
                // Читаем размер сообщения (первые 10 байт)
                if (socket->bytesAvailable() < 10) return;
                QByteArray sizeData = socket->read(10);
                bool ok;
                messageSize = sizeData.toInt(&ok);
                if (!ok || messageSize <= 0) {
                    QMessageBox::critical(this, "Error", "Invalid message size received");
                    socket->disconnectFromHost();
                    return;
                }
                buffer.clear();
            }

            // Читаем оставшиеся данные
            buffer.append(socket->readAll());

            if (buffer.size() >= messageSize) {
                // Парсим JSON
                QJsonParseError parseError;
                QJsonDocument jsonDoc = QJsonDocument::fromJson(buffer.left(messageSize), &parseError);

                if (jsonDoc.isNull()) {
                    QMessageBox::critical(this, "Error", "JSON Parse Error: " + parseError.errorString());
                    socket->disconnectFromHost();
                    return;
                }

                QJsonArray jsonArray = jsonDoc.array();
                textEdit->clear();

                for (const QJsonValue &value : jsonArray) {
                    QJsonObject obj = value.toObject();
                    textEdit->append("ID: " + QString::number(obj["id"].toInt()));
                    textEdit->append("Date: " + obj["date"].toString());
                    textEdit->append("Title: " + obj["title"].toString());
                    textEdit->append("Description: " + obj["description"].toString());
                    textEdit->append("Lat: " + QString::number(obj["lat"].toDouble()));
                    textEdit->append("Lon: " + QString::number(obj["lon"].toDouble()));
                    textEdit->append("Type: " + obj["type"].toString());
                    textEdit->append("---");
                }

                messageSize = -1;
                buffer.clear();
                socket->disconnectFromHost();
            }
        }
    });

    connect(socket, &QTcpSocket::errorOccurred, this, [this, socket]() {
        QMessageBox::critical(this, "Error", "Socket Error: " + socket->errorString());
        socket->deleteLater();
    });

    socket->connectToHost("127.0.0.1", 12346);
}
